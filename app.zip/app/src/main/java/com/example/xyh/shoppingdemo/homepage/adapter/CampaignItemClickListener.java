package com.example.xyh.shoppingdemo.homepage.adapter;

import android.view.View;

import com.example.xyh.shoppingdemo.homepage.model.CampaignBean;

/**
 * Created by xyh on 2016/9/12.
 */
public interface CampaignItemClickListener {
    void onClickListener(View v, int position, CampaignBean.Bean bean);
}
