package com.example.xyh.shoppingdemo.homepage.presenter;

import android.view.View;

/**
 * Created by xyh on 2016/9/12.
 */
public interface OnCampaignClickListener {
    void onClickListener(View view, int position);
}
